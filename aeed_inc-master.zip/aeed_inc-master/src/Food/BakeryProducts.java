package Food;

public class BakeryProducts extends Food {
}
