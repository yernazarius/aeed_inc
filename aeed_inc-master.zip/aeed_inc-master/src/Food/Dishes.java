package Food;

public class Dishes extends Food {
}
