package Food;

public class Drinks extends Food {
}
