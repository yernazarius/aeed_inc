package Food;

public class Salads extends Food {
}
