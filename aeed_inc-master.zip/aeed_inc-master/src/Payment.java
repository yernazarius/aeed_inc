public interface Payment {
    double calculateCheck();
}
