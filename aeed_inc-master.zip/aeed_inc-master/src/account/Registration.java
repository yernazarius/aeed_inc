package account;
import User.Users;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
public class Registration extends Users {
    static String connectionUrl = "jdbc:postgresql://localhost:5432/CanteenDB";
    static Scanner scanner = new Scanner(System.in);


    public static void addClient(Users user){


        String sql = " insert into clients (name, surname, phoneNumber, password)"
                + " values (?, ?, ?, ?)";

        try(Connection con = DriverManager.getConnection(connectionUrl,"postgres","12345");
            PreparedStatement preparedStmt = con.prepareStatement(sql)) {

            String name, surname, phoneNumber, password;


            name = scanner.next();
            System.out.println("What is your second name?");
            surname = scanner.next();
            System.out.println("Please, share with us your telephone number");
            phoneNumber = scanner.next();
            System.out.println("Set your password");
            password = scanner.next();

            preparedStmt.setString(1, name);
            preparedStmt.setString(2, surname);
            preparedStmt.setString(3, phoneNumber);
            preparedStmt.setString(5, password);
            preparedStmt.execute();

            user.setName(name);
            user.setSurname(surname);
            user.setPhoneNumber(phoneNumber);
            user.setPassword(password);
        }
        catch (Exception e){
            System.out.println(e + "Connection Error!");
        }
    }
    public static Users findClient(String phoneNumber, String password){
        Users client = new Users();
        String sql= "select id,name, surname, phoneNumber, password "
                + "from Users "
                + "where phoneNumber = ?";

        try(Connection con = DriverManager.getConnection(connectionUrl,"postgres","12345");
            PreparedStatement preparedStmt = con.prepareStatement(sql)){

            preparedStmt.setString(1,phoneNumber);
            ResultSet rs = preparedStmt.executeQuery();

            while(rs.next()){
                while(!rs.getString("password").equals(password)){
                    System.out.println("Wrong password! Please try again");
                    password = scanner.next();
                }

//                client = new Users(rs.getInt("id"),rs.getString("firstname"), rs.getString("secondname"),
//                        rs.getInt("age"),rs.getString("telephonenumber") , rs.getString("password"));

            }
        }
        catch (Exception e){
            System.out.println(e + "Connection Error!");
        }

        return client;
    }


}
