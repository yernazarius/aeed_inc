package db;

import db.IDB;
import db.PostgresDB;
import java.sql.Statement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.*;
import User.Users;
import java.util.Scanner;
public class Main extends PostgresDB{
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        PostgresDB data = new PostgresDB();
        Statement  st = data.getConnection().createStatement();
        ResultSet rs = null;
        rs = st.executeQuery("select * from Food");
        System.out.println(rs.getClass());
        while (rs.next()){
            System.out.println(rs.getInt("id")+" "+
                    rs.getString("name")+" "+rs.getString("price"));
        }
        try {
            data.getConnection().close();
        } catch (Exception e){
            System.out.println("Exception occured while closing");
        }
        Scanner input = new Scanner(System.in);
        System.out.println("Hello! Welcome to online canteen system. We are pleased to see you there!");
        System.out.println("Do you have account?" +
                "\nPlease enter Yes or No");
        String answer = input.next();

        if(answer.equals("NO") || answer.equals("nO") || answer.equals("No") || answer.equals("no")){
            System.out.println("Not a problem, let's create your account:" + "\nWhat is your first name?");
//            addClient(client);
        }
        Users user = new Users(input.next(), input.next());
        System.out.println(user.getName()+" here is the menu!");

    }
}